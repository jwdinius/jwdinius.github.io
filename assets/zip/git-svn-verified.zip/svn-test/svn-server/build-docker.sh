docker build \
    --build-arg USER=$1 \
    --build-arg PASSWORD=$2 \
    --network=host \
    -t svn-server \
    .
