docker run -d \
    --name svn-server-c \
    -v $(pwd)/svn:/home/svn \
    --network=host \
    svn-server

# USER: {svn-username}
# PASSWORD: {svn-password}

### SETUP NEW REPO ###
## SERVER SIDE ##
# STEP 1: attach terminal to svn-server-c
# docker exec -it svn-server-c /bin/bash
# STEP 2: create new repo using svnadmin
# svnadmin create /home/svn/{project-name}
# STEP 3: change permissions so user={svn-username} can push/pull from svn server
# chown -R www-data:subversion /home/svn/{project-name}
# chmod -R g+rws /home/svn/{project-name}

## CLIENT SIDE ##
# STEP 1: checkout repo
# svn co --user {svn-username} http://localhost/svn/{project-name} # enter password after
# STEP 2: create branches tags trunks
# cd {project-name} && mkdir branches tags trunk
# STEP 3: add and commit local changes to the server
# svn add branches tags trunk && svn ci -m "adding standard layout"
