# How To git-svn
Starting from work using svn-server inside of Docker container.

url to svn server is http://localhost/svn

Helpful links:

* https://git-scm.com/docs/git-svn/1.5.5
* http://trac.parrot.org/parrot/wiki/git-svn-tutorial
* https://objectpartners.com/2014/02/04/getting-started-with-git-svn/
* https://kapeli.com/cheat_sheets/Git_Subversion.docset/Contents/Resources/Documents/index
* https://mojodna.net/2009/02/24/my-work-git-workflow.html

## create new repo locally and push to server

_Repos should be (maybe have to be) created by using svnadmin on the server-side._

## clone existing SVN repo
```
git svn clone http://localhost/svn/{repo-name} {repos-name} -s
```

`s` is for standard layout; e.g. branches/tags/trunk

This sets up a git-like local repo to work with.  Quite handy!

## create and track svn branch

```
git svn branch -m "{your-message-here}" {name-of-branch}
#git branch -a  # list remote branches that git knows about VERY USEFUL
#git svn fetch  # fetches all branches, so use cautiously
git checkout -b {name-of-branch}-local remotes/origin/{name-of-branch}  # adding `-local` removes git warning about ambiguity
... (do bunch of stuff locally, using git workflow)
## When happy with your work...
git svn dcommit  # commits to branch
```

## merge branch into other branch (including trunk)

See this [post](https://stackoverflow.com/questions/2835791/git-svn-reset-tracking-for-master)'s accepted answer.

```
git checkout {to-branch}
git reset --hard {remote-to-to-branch}  # e.g. remotes/origin/trunk THE EXTRA "to" IS NOT A TYPO!
git merge --no-ff  {remote-to-from-branch}  # the --no-ff option is important; see post answer, brings up editor with a default merge message
git svn rebase {remote-to-to-branch}  # e.g. remotes/origin/trunk
git svn dcommit
```

## how to ignore files

For now, just add a `.gitignore` file before doing local git workflow stuff.  Do `git svn dcommit` after satisfied with local git changes.  Things you want to ignore won't be committed to git and not committed to svn by git svn.
